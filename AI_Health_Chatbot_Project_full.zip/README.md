# AI Health Support Chatbot - Demo Project
This archive contains an end-to-end demo project for the **AI Health Support Chatbot** described in your proposal.
Files included:
- `app.py` - Flask web app (backend) that loads model and serves chat UI.
- `train_model.py` - Script to train a simple ML model on the provided mock dataset and save `model.pkl` and `vectorizer.pkl`.
- `requirements.txt` - Python dependencies.
- `symptom_disease_mock.csv` - Small example dataset to run the demo locally.
- `templates/index.html` - Front-end chat UI.
- `static/style.css` - Basic CSS for UI.
- `static/script.js` - Client-side JS to talk to backend.
- `README.md` - This file.


## Quick start (local)
1. Create a Python virtual environment: `python -m venv venv && source venv/bin/activate` (Linux/macOS) or `venv\Scripts\activate` (Windows).
2. Install dependencies: `pip install -r requirements.txt`.
3. Train model: `python train_model.py` (this creates `model.pkl` and `vectorizer.pkl`).
4. Run app: `python app.py` and open `http://127.0.0.1:5000` in your browser.


## Notes
- The dataset included is a tiny mock dataset for demonstration. Replace it with a larger real dataset (e.g., from Kaggle) for improved accuracy.
- The project is for educational/demo use only and is **not** a medical diagnostic tool.
