from flask import Flask, render_template, request, jsonify
import joblib, os, re, sqlite3, pandas as pd
import spacy, json
from datetime import datetime

app = Flask(__name__)
MODEL_PATH = 'model.pkl'
VEC_PATH = 'vectorizer.pkl'
DATA_PATH = 'symptom_disease_mock.csv'
DB_PATH = 'chat_logs.db'

# Load artifacts
model = joblib.load(MODEL_PATH) if os.path.exists(MODEL_PATH) else None
vectorizer = joblib.load(VEC_PATH) if os.path.exists(VEC_PATH) else None
df = pd.read_csv(DATA_PATH)

# spaCy
try:
    nlp = spacy.load('en_core_web_sm')
except Exception as e:
    print('spaCy model not loaded. Run: python -m spacy download en_core_web_sm')
    nlp = None

# Initialize DB
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY, timestamp TEXT, user_input TEXT, cleaned TEXT, prediction TEXT, response TEXT)''')
    conn.commit(); conn.close()

init_db()

def clean_text(text):
    text = str(text).lower()
    text = re.sub('[^a-z0-9 ]',' ', text)
    text = ' '.join(text.split())
    return text

def extract_symptoms(text):
    text = str(text).lower()
    if nlp:
        doc = nlp(text)
        tokens = [token.lemma_ for token in doc if not token.is_stop and token.is_alpha]
        return ' '.join(tokens)
    return clean_text(text)

def detect_intent(text):
    text_l = text.lower()
    greetings = ['hi','hello','hey','good morning','good evening']
    thanks = ['thanks','thank you','thx']
    if any(g in text_l for g in greetings):
        return 'greeting'
    if any(t in text_l for t in thanks):
        return 'thanks'
    # otherwise assume symptom description
    return 'symptom'

def ask_followup(prediction, cleaned):
    # simple heuristic: if common symptom words missing, ask clarifying Qs
    followups = {
        'Heart Attack': 'Do you have chest pain radiating to left arm or jaw, sweating, or fainting? (yes/no)',
        'Flu': 'Do you have body aches and high fever? (yes/no)',
        'Common Cold': 'Do you have runny nose and sneezing? (yes/no)',
        'Migraine': 'Is your headache one-sided or sensitive to light/noise? (yes/no)'
    }
    return followups.get(prediction, None)

def log_interaction(user_input, cleaned, prediction, response):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('INSERT INTO logs (timestamp, user_input, cleaned, prediction, response) VALUES (?,?,?,?,?)', (datetime.utcnow().isoformat(), user_input, cleaned, prediction, response))
    conn.commit(); conn.close()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    user_input = request.form.get('message', '')
    intent = detect_intent(user_input)
    if intent == 'greeting':
        return jsonify({'response': 'Hello! Describe your symptoms and I will try to help.'})
    if intent == 'thanks':
        return jsonify({'response': 'You're welcome — glad to help!'})
    cleaned = extract_symptoms(user_input)
    if model is None or vectorizer is None:
        return jsonify({'response': 'Model artifacts missing. Run training.'})
    vec = vectorizer.transform([cleaned])
    pred = model.predict(vec)[0]
    advice = df[df['disease'] == pred].iloc[0]['precautions'] if not df[df['disease'] == pred].empty else 'Follow general precautions and consult a doctor.'
    # follow-up question if needed
    follow = ask_followup(pred, cleaned)
    if follow:
        response = f'Possible condition: {pred}. {advice} Follow-up: {follow}'
    else:
        response = f'Possible condition: {pred}. Advice: {advice}'
    # Log
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('INSERT INTO logs (timestamp, user_input, cleaned, prediction, response) VALUES (?,?,?,?,?)', (datetime.utcnow().isoformat(), user_input, cleaned, pred, response))
        conn.commit(); conn.close()
    except Exception as e:
        print('DB log error', e)
    return jsonify({'response': response})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
