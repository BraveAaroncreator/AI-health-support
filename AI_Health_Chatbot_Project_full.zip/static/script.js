document.getElementById('chat-form').addEventListener('submit', async function(e){
  e.preventDefault();
  const msgInput = document.getElementById('message');
  const text = msgInput.value.trim();
  if(!text) return;
  const box = document.getElementById('chat-box');
  const userP = document.createElement('p'); userP.innerHTML = '<b>You:</b> '+text; box.appendChild(userP);
  msgInput.value = '';
  try{
    const form = new URLSearchParams(); form.append('message', text);
    const resp = await fetch('/predict', { method:'POST', body: form });
    const data = await resp.json();
    const botP = document.createElement('p'); botP.innerHTML = '<b>Bot:</b> '+data.response; box.appendChild(botP);
    box.scrollTop = box.scrollHeight;
  } catch(err){
    const errP = document.createElement('p'); errP.innerHTML = '<b>Bot:</b> Error contacting server.'; box.appendChild(errP);
  }
});
